package com.jarvis.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.provider.MediaStore
import android.provider.Settings
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.pow

private val Bg = Color(0xFF050914)
private val Panel = Color(0xFF0B1424)
private val Cyan = Color(0xFF45D9FF)
private val Muted = Color(0xFF9DB2C8)
private val Green = Color(0xFF69F0AE)
@Volatile private var activeTimerJob: Job? = null

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisScreen(onSpeak = { speak(it) }, onStopSpeaking = { tts?.stop() }) }
    }
    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            // A restrained, slightly slower delivery gives the system voice a more composed
            // cinematic-assistant feel. The actual accent/voice depends on installed TTS voices.
            tts?.setSpeechRate(0.92f)
            tts?.setPitch(0.88f)
            val languageResult = tts?.setLanguage(Locale.UK)
            if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.getDefault())
            }
        }
    }
    private fun speak(text: String) { if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}


data class ChatLine(val from: String, val text: String)

private data class AgentRoute(val universe: String, val agent: String, val mission: String)

private val universeDescriptions = listOf(
    "NEXUS" to "Central coordinator",
    "AGORA" to "Revenue, opportunities and value",
    "CODEX" to "Knowledge, research and learning",
    "FORGE" to "Building, coding and delivery",
    "TRESOR" to "Finance, budgets and trade-offs",
    "HERALD" to "Growth, communication and campaigns",
    "SHIELD" to "Security, privacy and reliability"
)

private val specialistAgents = listOf(
    "NEXUS • Orchestrator", "AGORA • Opportunity Scout", "AGORA • Revenue Strategist",
    "AGORA • Market Analyst", "AGORA • Pricing Analyst", "AGORA • Sales Planner",
    "CODEX • Research Analyst", "CODEX • Tutor", "CODEX • Concept Explainer",
    "CODEX • Fact Checker", "CODEX • Knowledge Librarian", "FORGE • Architect",
    "FORGE • Android Developer", "FORGE • Code Reviewer", "FORGE • Debugger",
    "FORGE • Workflow Builder", "TRESOR • Budget Analyst", "TRESOR • Finance Educator",
    "TRESOR • Cost Planner", "TRESOR • Risk Analyst", "HERALD • Growth Strategist",
    "HERALD • Content Writer", "HERALD • Campaign Planner", "HERALD • Brand Advisor",
    "SHIELD • Privacy Advisor", "SHIELD • Security Reviewer", "SHIELD • Permission Auditor",
    "SHIELD • Safety Monitor", "SHIELD • Reliability Analyst"
)

private fun routeAgent(message: String, preferredUniverse: String = "AUTO", preferredAgent: String = "AUTO"): AgentRoute {
    val text = message.lowercase(Locale.ROOT)
    val pinnedUniverse = if (preferredAgent != "AUTO") preferredAgent.substringBefore(" • ") else preferredUniverse
    val chosen = if (pinnedUniverse != "AUTO") pinnedUniverse else when {
        listOf("budget", "money", "finance", "cost", "saving", "price", "expense", "investment").any { text.contains(it) } -> "TRESOR"
        listOf("security", "privacy", "permission", "safe", "risk", "protect", "password").any { text.contains(it) } -> "SHIELD"
        listOf("code", "coding", "program", "debug", "build", "app", "android", "workflow", "script").any { text.contains(it) } -> "FORGE"
        listOf("grow", "marketing", "content", "caption", "campaign", "brand", "social", "audience").any { text.contains(it) } -> "HERALD"
        listOf("revenue", "business", "customer", "sales", "market", "opportunity", "pricing", "product idea").any { text.contains(it) } -> "AGORA"
        listOf("explain", "teach", "study", "learn", "research", "what is", "why", "formula", "jee", "physics", "chemistry", "math").any { text.contains(it) } -> "CODEX"
        else -> "NEXUS"
    }
    if (preferredAgent != "AUTO") {
        val agentName = preferredAgent.substringAfter(" • ", "Orchestrator")
        return AgentRoute(chosen, agentName, "Apply the selected specialist role to the request, remain honest about capabilities, and coordinate through the same AI model.")
    }
    val (agent, mission) = when (chosen) {
        "AGORA" -> when {
            listOf("price", "pricing", "cost").any { text.contains(it) } -> "Pricing Analyst" to "Evaluate value and pricing assumptions."
            listOf("sales", "customer", "revenue").any { text.contains(it) } -> "Revenue Strategist" to "Explore practical value and revenue options."
            else -> "Opportunity Scout" to "Identify opportunities and compare trade-offs."
        }
        "CODEX" -> when {
            listOf("jee", "physics", "chemistry", "math", "formula", "study", "teach", "learn").any { text.contains(it) } -> "Tutor" to "Teach step by step, checking understanding."
            listOf("research", "source", "fact", "verify").any { text.contains(it) } -> "Research Analyst" to "Separate evidence from assumptions."
            else -> "Concept Explainer" to "Make the subject clear and structured."
        }
        "FORGE" -> when {
            listOf("debug", "error", "crash", "broken").any { text.contains(it) } -> "Debugger" to "Diagnose likely causes and testable fixes."
            listOf("review", "check code").any { text.contains(it) } -> "Code Reviewer" to "Review correctness, safety and maintainability."
            listOf("android", "app", "build").any { text.contains(it) } -> "Android Developer" to "Plan implementation with platform limits."
            else -> "Architect" to "Break the build into practical components."
        }
        "TRESOR" -> if (listOf("budget", "expense", "saving").any { text.contains(it) }) "Budget Analyst" to "Organize costs and realistic trade-offs." else "Finance Educator" to "Explain financial concepts without promises."
        "HERALD" -> if (listOf("caption", "write", "post", "script").any { text.contains(it) }) "Content Writer" to "Create clear, audience-aware communication." else "Growth Strategist" to "Suggest sustainable ways to reach an audience."
        "SHIELD" -> if (listOf("permission", "android", "privacy").any { text.contains(it) }) "Permission Auditor" to "Explain permissions and minimize access." else "Security Reviewer" to "Identify risks and safer alternatives."
        else -> "Orchestrator" to "Coordinate the right specialist and keep the response focused."
    }
    return AgentRoute(chosen, agent, mission)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JarvisScreen(onSpeak: (String) -> Unit, onStopSpeaking: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("jarvis", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var personality by remember { mutableStateOf(prefs.getString("personality", "J.A.R.V.I.S.") ?: "J.A.R.V.I.S.") }
    var preferredUniverse by remember { mutableStateOf(prefs.getString("universe", "AUTO") ?: "AUTO") }
    var preferredAgent by remember { mutableStateOf(prefs.getString("agent", "AUTO") ?: "AUTO") }
    var activeAgent by remember { mutableStateOf("NEXUS • Orchestrator") }
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var showCollection by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("LOCAL MODE • READY") }
    var busy by remember { mutableStateOf(false) }
    val notes = remember { mutableStateListOf<String>().apply { addAll(loadList(prefs, "notes")) } }
    val tasks = remember { mutableStateListOf<String>().apply { addAll(loadList(prefs, "tasks")) } }
    val chat = remember { mutableStateListOf<ChatLine>().apply { add(ChatLine("JARVIS", "Systems initialized, sir. Local commands are ready. Configure an AI backend in Settings for online reasoning.")) } }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { input = spoken; runCommand(spoken, personality, backendUrl, preferredUniverse, preferredAgent, prefs, notes, tasks, chat, context, onSpeak, onStopSpeaking, scope, { status = it }, { busy = it }, { activeAgent = it }) }
        }
    }

    fun listen() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
            }
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "Speech recognition is not available on this device. Try typing a command.", Toast.LENGTH_LONG).show()
        }
    }

    val reactorMotion = rememberInfiniteTransition(label = "reactorMotion")
    val reactorRotation by reactorMotion.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(animation = tween(14000, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "reactorRotation"
    )
    val reactorPulse by reactorMotion.animateFloat(
        initialValue = 0.35f, targetValue = 0.85f,
        animationSpec = infiniteRepeatable(animation = tween(1800), repeatMode = RepeatMode.Reverse),
        label = "reactorPulse"
    )

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Bg, topBar = {
            TopAppBar(
                title = { Column { Text("J.A.R.V.I.S.", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Text("JUST A RATHER VERY INTELLIGENT SYSTEM", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp) } },
                actions = { TextButton(onClick = { showSettings = true }) { Text("SETTINGS", color = Cyan, fontSize = 11.sp) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
            )
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 14.dp)) {
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF0C2638), Color(0xFF07101E))), RoundedCornerShape(22.dp)).padding(18.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(132.dp).background(Brush.radialGradient(listOf(Color(0xFF1C7897), Color(0xFF10263B), Bg)), CircleShape), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(116.dp).rotate(reactorRotation).border(1.dp, Cyan.copy(alpha = reactorPulse), CircleShape), contentAlignment = Alignment.Center) {
                                Box(Modifier.size(96.dp).rotate(-reactorRotation * 1.4f).border(1.dp, Cyan.copy(alpha = 0.28f), CircleShape), contentAlignment = Alignment.Center) {
                                    Box(Modifier.size(76.dp).background(Color(0xFF0B2233), CircleShape).border(1.dp, Cyan.copy(alpha = 0.7f), CircleShape), contentAlignment = Alignment.Center) {
                                        Text("J", color = Cyan, fontSize = 48.sp, fontWeight = FontWeight.ExtraLight)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(personality, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
                        Text(status, color = Green, fontSize = 10.sp, letterSpacing = 1.4.sp)
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("J.A.R.V.I.S.", "F.R.I.D.A.Y.", "M.A.Y.A.", "IRON MAN", "NATASHA").forEach { name ->
                                FilterChip(selected = personality == name, onClick = { personality = name; prefs.edit().putString("personality", name).apply() }, label = { Text(name, fontSize = 9.sp) })
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusCard("MODE", if (backendUrl.isBlank()) "LOCAL CORE" else "AI LINK SET", Modifier.weight(1f))
                    StatusCard("NOTES", notes.size.toString(), Modifier.weight(1f))
                    StatusCard("TASKS", tasks.size.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("AI UNIVERSE COLLECTION", color = Cyan, fontSize = 10.sp, letterSpacing = 1.3.sp, fontWeight = FontWeight.Bold)
                        Text("7 domains • 29 specialist roles", color = Muted, fontSize = 9.sp)
                    }
                    TextButton(onClick = { showCollection = true }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                        Text("OPEN COLLECTION", color = Green, fontSize = 9.sp)
                    }
                }
                Text("Active: $activeAgent", color = Green, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp, bottom = 5.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (listOf("AUTO") + universeDescriptions.map { it.first }).forEach { domain ->
                        FilterChip(
                            selected = preferredUniverse == domain,
                            onClick = { preferredUniverse = domain; prefs.edit().putString("universe", domain).apply() },
                            label = { Text(domain, fontSize = 9.sp) }
                        )
                    }
                }
                Spacer(Modifier.height(5.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (listOf("AUTO") + specialistAgents).forEach { agent ->
                        FilterChip(
                            selected = preferredAgent == agent,
                            onClick = { preferredAgent = agent; prefs.edit().putString("agent", agent).apply() },
                            label = { Text(if (agent == "AUTO") "AUTO AGENT" else agent, fontSize = 9.sp) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("CONVERSATION", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                LazyColumn(Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(chat) { line ->
                        Column(Modifier.fillMaxWidth().background(if (line.from == "YOU") Color(0xFF11283A) else Color(0xFF0D1B2C), RoundedCornerShape(12.dp)).padding(10.dp)) {
                            Text(line.from, color = if (line.from == "YOU") Green else Cyan, fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(3.dp)); Text(line.text, color = Color(0xFFE5F1FA), fontSize = 14.sp)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Speak or type a command…", fontSize = 13.sp) }, singleLine = true, shape = RoundedCornerShape(15.dp))
                    Button(onClick = { listen() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(44.dp), shape = CircleShape) { Text("🎙", fontSize = 18.sp) }
                    IconButton(onClick = { onStopSpeaking(); status = "SPEECH STOPPED" }, modifier = Modifier.size(36.dp)) { Text("■", color = Color(0xFFFF8A80), fontSize = 16.sp) }
                    Button(onClick = {
                        val text = input.trim(); if (text.isNotEmpty()) { input = ""; runCommand(text, personality, backendUrl, preferredUniverse, preferredAgent, prefs, notes, tasks, chat, context, onSpeak, onStopSpeaking, scope, { status = it }, { busy = it }, { activeAgent = it }) }
                    }, enabled = !busy, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(44.dp), shape = CircleShape) { Text("➤", fontSize = 20.sp) }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("System status", "What can you do?", "What time is it?", "Help").forEach { quick ->
                AssistChip(onClick = { input = quick; runCommand(quick, personality, backendUrl, preferredUniverse, preferredAgent, prefs, notes, tasks, chat, context, onSpeak, onStopSpeaking, scope, { status = it }, { busy = it }, { activeAgent = it }) }, label = { Text(quick, fontSize = 10.sp) })
            }
        }
        Text("Voice input uses Android speech services. Wake-word listening is not enabled; use the microphone button.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp, bottom = 6.dp))
            }
        }

        if (showCollection) {
            AlertDialog(
                onDismissRequest = { showCollection = false },
                title = { Text("J.A.R.V.I.S. • UNIVERSE COLLECTION", color = Cyan) },
                text = {
                    Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("PERSONA MODES", color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Text("J.A.R.V.I.S. • composed executive assistant\nF.R.I.D.A.Y. • fast analytical assistant\nM.A.Y.A. • adaptive supportive assistant\nIRON MAN • inventor and engineering mode\nNATASHA • discreet, privacy-aware mode", color = Color.White, fontSize = 12.sp)
                        HorizontalDivider(color = Cyan.copy(alpha = 0.35f))
                        Text("SPECIALIST UNIVERSES", color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        universeDescriptions.forEach { (universe, description) ->
                            val roles = specialistAgents.filter { it.startsWith("$universe •") }.map { it.substringAfter(" • ") }
                            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(10.dp)) {
                                Text(universe, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(description, color = Muted, fontSize = 11.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(roles.joinToString("  •  "), color = Color.White, fontSize = 11.sp, lineHeight = 17.sp)
                            }
                        }
                        HorizontalDivider(color = Cyan.copy(alpha = 0.35f))
                        Text("HOW THE COLLECTION WORKS", color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Text("NEXUS coordinates. AUTO selects a suitable specialist based on your message; you can also pin a universe or role using the chips on the main screen. This starter uses one configured AI model with role instructions—not 29 independent AI models. Some advanced features require the optional backend.", color = Color.White, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                },
                confirmButton = { TextButton(onClick = { showCollection = false }) { Text("CLOSE") } }
            )
        }

        if (showSettings) {
            AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("JARVIS SETTINGS") }, text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Optional AI backend URL", color = Cyan, fontSize = 12.sp)
                    OutlinedTextField(value = backendUrl, onValueChange = { backendUrl = it }, placeholder = { Text("https://your-backend.example/chat") }, singleLine = true)
                    Text("Keep API keys on the backend, never in this app. Leave blank to use local commands only.", color = Muted, fontSize = 11.sp)
                    Text("Saved notes: ${notes.size} • Tasks: ${tasks.size}", color = Muted, fontSize = 12.sp)
                    Text("Mind Network: 6 specialist domains, 29 role-based agents. AUTO routes each request; choosing a domain pins that specialist family.", color = Muted, fontSize = 11.sp)
                    TextButton(onClick = { notes.clear(); tasks.clear(); prefs.edit().remove("notes").remove("tasks").apply() }) { Text("CLEAR LOCAL NOTES AND TASKS", color = Color(0xFFFF8A80)) }
                }
            }, confirmButton = { TextButton(onClick = { prefs.edit().putString("backend_url", backendUrl.trim()).apply(); showSettings = false; status = if (backendUrl.isBlank()) "LOCAL MODE • READY" else "AI ENDPOINT CONFIGURED" }) { Text("SAVE") } }, dismissButton = { TextButton(onClick = { showSettings = false }) { Text("CANCEL") } })
        }
    }
}

@Composable
private fun StatusCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(12.dp)).padding(10.dp)) {
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        Text(value, color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

private fun runCommand(
    raw: String, personality: String, backendUrl: String, preferredUniverse: String, preferredAgent: String, prefs: android.content.SharedPreferences,
    notes: MutableList<String>, tasks: MutableList<String>, chat: MutableList<ChatLine>, context: Context,
    speak: (String) -> Unit, stopSpeaking: () -> Unit, scope: kotlinx.coroutines.CoroutineScope,
    setStatus: (String) -> Unit, setBusy: (Boolean) -> Unit, setAgent: (String) -> Unit
) {
    chat.add(ChatLine("YOU", raw))
    val cmd = raw.trim()
    val lower = cmd.lowercase(Locale.ROOT)
    val route = routeAgent(cmd, preferredUniverse, preferredAgent)
    setAgent("${route.universe} • ${route.agent}")
    if (lower.contains("stop speaking") || lower == "be quiet" || lower == "stop talking") {
        stopSpeaking()
        chat.add(ChatLine("JARVIS", "Speech stopped, sir."))
        setStatus("LOCAL COMMAND • SPEECH STOPPED")
        return
    }
    val localReply: String? = when {
        lower.contains("what time") || lower == "time" || lower.contains("current time") || lower == "time check" -> "It is ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}, sir."
        lower.contains("today's date") || lower.contains("what date") || lower == "date" || lower.contains("date check") -> "Today is ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())}, sir."
        lower.contains("who are you") || lower.contains("introduce yourself") || lower.contains("what is jarvis") -> "I am J.A.R.V.I.S., sir — Just A Rather Very Intelligent System. I am your personal assistant interface, designed to help with information, organisation, study, and supported actions on this device. I will tell you plainly when a capability is unavailable."
        lower.contains("system status") || lower.contains("status report") || lower == "diagnostics" || lower.contains("system diagnostics") -> {
            val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryText = if (level >= 0 && scale > 0) "battery at ${level * 100 / scale} percent" else "battery status unavailable"
            val aiText = if (backendUrl.isBlank()) "offline command systems active; cloud reasoning not configured" else "AI endpoint configured; connectivity not yet verified"
            "System report, sir. $batteryText. ${notes.size} saved notes and ${tasks.size} tasks in local memory. Mind Network has 29 role-based specialist profiles across six work domains plus Nexus coordination. Current route: ${route.universe}, ${route.agent}. $aiText. Voice input requires the microphone button; always-on wake-word listening is not enabled."
        }
        lower.contains("what can you do") || lower.contains("capabilities") || lower == "help" -> "At your service, sir. I can manage local notes and tasks, report the time and battery, calculate arithmetic, explain a few study formulas offline, start an in-app timer, open supported Android screens, and search the web. With a configured AI backend, I can answer broader questions. I also route requests through a Mind Network of 29 role-based specialists across Agora, Codex, Forge, Tresor, Herald and Shield, coordinated by Nexus. These are specialist roles, not 29 separate running AI models. I cannot silently control every app or listen for a wake word in the background in this version. Say 'system status' for a diagnostic report."
        lower.contains("battery") -> {
            val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) "Your battery is at ${level * 100 / scale} percent, sir." else "I cannot read the battery level on this device."
        }
        lower.startsWith("start a ") && lower.contains("timer") || lower.startsWith("start timer") -> {
            val amount = Regex("(\\d+)").find(lower)?.groupValues?.get(1)?.toLongOrNull() ?: 5L
            val millis = when {
                lower.contains("hour") -> amount * 60L * 60L * 1000L
                lower.contains("second") -> amount * 1000L
                else -> amount * 60L * 1000L
            }.coerceIn(1000L, 24L * 60L * 60L * 1000L)
            activeTimerJob?.cancel()
            activeTimerJob = scope.launch {
                delay(millis)
                speak("Your timer is complete, sir.")
                Toast.makeText(context.applicationContext, "JARVIS timer complete", Toast.LENGTH_LONG).show()
            }
            val duration = when { lower.contains("hour") -> "$amount hour(s)"; lower.contains("second") -> "$amount second(s)"; else -> "$amount minute(s)" }
            "Timer started for $duration, sir. Keep JARVIS running for the timer to complete."
        }
        lower.contains("cancel timer") || lower.contains("stop timer") -> {
            val wasActive = activeTimerJob?.isActive == true
            activeTimerJob?.cancel(); activeTimerJob = null
            if (wasActive) "Timer cancelled, sir." else "There is no active timer to cancel, sir."
        }
        lower.startsWith("calculate ") || lower.startsWith("evaluate ") -> {
            val expression = cmd.replace(Regex("(?i)^(calculate|evaluate)\\s*"), "")
                .replace("×", "*").replace("÷", "/")
                .replace(Regex("(?i)\\bplus\\b"), "+")
                .replace(Regex("(?i)\\bminus\\b"), "-")
                .replace(Regex("(?i)\\btimes\\b"), "*")
                .replace(Regex("(?i)\\bdivided by\\b"), "/").trimEnd('?', '.', ' ')
            val result = safeCalculate(expression)
            if (result == null) "I couldn't safely evaluate that expression, sir. Try something like calculate (12 + 8) / 4." else "The result is ${formatNumber(result)}, sir."
        }
        lower.contains("newton's second law") || lower.contains("newtons second law") -> "Newton's second law states that net force equals mass multiplied by acceleration: F = ma. In SI units, force is measured in newtons, mass in kilograms, and acceleration in metres per second squared."
        lower.contains("quadratic formula") -> "For ax² + bx + c = 0, the quadratic formula is x = (-b ± √(b² - 4ac)) / (2a), where a is not zero."
        lower.contains("speed formula") || lower.contains("formula for speed") -> "Average speed = total distance divided by total time. SI unit: metre per second (m/s)."
        lower.startsWith("remember ") || lower.startsWith("save note ") || lower.startsWith("take a note ") -> {
            val value = cmd.replace(Regex("(?i)^(remember|save note|take a note)\\s*"), "").trim()
            if (value.isNotBlank()) { notes.add(value); saveList(prefs, "notes", notes); "Saved to your local notes, sir." } else "What would you like me to remember, sir?"
        }
        lower.contains("show notes") || lower.contains("read my notes") || lower == "notes" -> if (notes.isEmpty()) "You have no saved notes yet, sir." else "Your saved notes are: " + notes.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString(". ")
        lower.startsWith("create task ") || lower.startsWith("add task ") || lower.startsWith("remind me to ") -> {
            val value = when { lower.startsWith("create task ") -> cmd.substring(12); lower.startsWith("add task ") -> cmd.substring(9); else -> cmd.substring(13) }.trim()
            if (value.isNotBlank()) { tasks.add(value); saveList(prefs, "tasks", tasks); "Task saved locally: $value." } else "Tell me what task to add, sir."
        }
        lower.contains("show tasks") || lower.contains("pending tasks") || lower == "tasks" -> if (tasks.isEmpty()) "There are no saved tasks, sir." else "Your tasks are: " + tasks.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString(". ")
        lower.contains("open youtube") -> { openUrl(context, "https://www.youtube.com"); "Opening YouTube, sir. If the app is installed, Android may open it; otherwise it will open in a browser." }
        lower.contains("open chrome") -> { openAppOrUrl(context, "com.android.chrome", "https://www.google.com"); "Opening Chrome or your default browser, sir." }
        lower.contains("open dialer") || lower.contains("open phone") -> { openIntent(context, Intent(Intent.ACTION_DIAL)); "Opening the phone dialer, sir." }
        lower.contains("open camera") -> { openIntent(context, Intent(MediaStore.ACTION_IMAGE_CAPTURE)); "Opening the camera if a compatible camera app is available, sir." }
        lower.contains("open settings") || lower == "settings" -> { openIntent(context, Intent(Settings.ACTION_SETTINGS)); "Opening Android settings, sir." }
        lower.contains("open maps") || lower.contains("open navigation") -> { openUrl(context, "https://maps.google.com"); "Opening maps, sir." }
        lower.startsWith("search for ") || lower.startsWith("search the web for ") -> {
            val query = cmd.replace(Regex("(?i)^search( the web)? for\\s*"), "").trim()
            if (query.isNotBlank()) { openUrl(context, "https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8")); "Searching the web for $query, sir." } else "What would you like me to search for, sir?"
        }
        lower.contains("good morning") -> "Good morning, sir. Systems are standing by. What would you like to work on?"
        lower.contains("good evening") -> "Good evening, sir. I am ready when you are."
        lower.contains("wake up") || lower.contains("jarvis are you there") -> "Yes, sir. I'm here. How may I assist?"
        lower.contains("thank you") || lower == "thanks" -> "You're welcome, sir. Always a pleasure."
        lower.contains("good night") -> "Good night, sir. Your local notes and tasks will remain saved."
        else -> null
    }
    if (localReply != null) {
        chat.add(ChatLine("JARVIS", localReply)); setStatus("LOCAL COMMAND • COMPLETE"); speak(localReply); return
    }
    if (backendUrl.isBlank()) {
        val reply = "I don't have an AI backend configured yet, sir. Local commands still work. Open Settings to enter your secure backend's /chat URL."
        chat.add(ChatLine("JARVIS", reply)); setStatus("LOCAL MODE • AI NOT CONFIGURED"); speak(reply); return
    }
    setBusy(true); setStatus("THINKING • ONLINE")
    scope.launch {
        val reply = withContext(Dispatchers.IO) { callBackend(backendUrl, cmd, personality, route.universe, route.agent, route.mission, chat.takeLast(12)) }
        val final = reply ?: "I couldn't reach the configured AI service, sir. Check the backend URL and internet connection."
        chat.add(ChatLine("JARVIS", final)); setStatus(if (reply == null) "BACKEND ERROR" else "AI RESPONSE RECEIVED"); setBusy(false); speak(final)
    }
}

private fun callBackend(url: String, message: String, personality: String, universe: String, agent: String, mission: String, history: List<ChatLine>): String? = try {
    val json = JSONObject().put("message", message).put("personality", personality)
        .put("universe", universe).put("agent", agent).put("mission", mission)
        .put("history", JSONArray().apply { history.forEach { put(JSONObject().put("role", if (it.from == "YOU") "user" else "assistant").put("content", it.text)) } })
    val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
    val request = Request.Builder().url(url).post(body).build()
    OkHttpClient.Builder().callTimeout(25, TimeUnit.SECONDS).build().newCall(request).execute().use { response ->
        if (!response.isSuccessful) return null
        val text = response.body?.string() ?: return null
        JSONObject(text).optString("reply").takeIf { it.isNotBlank() }
    }
} catch (_: Exception) { null }

private fun formatNumber(value: Double): String = if (value % 1.0 == 0.0) value.toLong().toString() else String.format(Locale.ROOT, "%.6f", value).trimEnd('0').trimEnd('.')

private fun safeCalculate(expression: String): Double? {
    if (expression.isBlank() || expression.length > 100 || expression.any { it !in "0123456789.+-*/^() " }) return null
    return try { ArithmeticParser(expression).parse()?.takeIf { it.isFinite() } } catch (_: Exception) { null }
}

private class ArithmeticParser(private val source: String) {
    private var pos = 0
    fun parse(): Double? {
        val value = expression()
        whitespace()
        return if (pos == source.length && value.isFinite()) value else null
    }
    private fun expression(): Double {
        var value = term()
        while (true) {
            whitespace()
            value = when {
                consume('+') -> value + term()
                consume('-') -> value - term()
                else -> return value
            }
        }
    }
    private fun term(): Double {
        var value = power()
        while (true) {
            whitespace()
            value = when {
                consume('*') -> value * power()
                consume('/') -> value / power()
                else -> return value
            }
        }
    }
    private fun power(): Double {
        val value = unary()
        whitespace()
        return if (consume('^')) value.pow(power()) else value
    }
    private fun unary(): Double {
        whitespace()
        if (consume('+')) return unary()
        if (consume('-')) return -unary()
        if (consume('(')) {
            val value = expression()
            whitespace()
            if (!consume(')')) throw IllegalArgumentException("Missing closing parenthesis")
            return value
        }
        val start = pos
        var dots = 0
        while (pos < source.length && (source[pos].isDigit() || source[pos] == '.')) {
            if (source[pos] == '.') dots++
            pos++
        }
        if (start == pos || dots > 1) throw IllegalArgumentException("Invalid number")
        return source.substring(start, pos).toDouble()
    }
    private fun consume(ch: Char): Boolean {
        if (pos < source.length && source[pos] == ch) { pos++; return true }
        return false
    }
    private fun whitespace() { while (pos < source.length && source[pos].isWhitespace()) pos++ }
}

private fun openIntent(context: Context, intent: Intent) {
    try { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(intent) }
    catch (_: Exception) { Toast.makeText(context, "That action is not available on this device.", Toast.LENGTH_SHORT).show() }
}

private fun openAppOrUrl(context: Context, packageName: String, fallbackUrl: String) {
    val launch = context.packageManager.getLaunchIntentForPackage(packageName)
    if (launch != null) openIntent(context, launch) else openUrl(context, fallbackUrl)
}

private fun openUrl(context: Context, url: String) {
    try { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (_: Exception) { Toast.makeText(context, "No compatible application found.", Toast.LENGTH_SHORT).show() }
}

private fun loadList(prefs: android.content.SharedPreferences, key: String): List<String> = try {
    val arr = JSONArray(prefs.getString(key, "[]") ?: "[]"); (0 until arr.length()).map { arr.getString(it) }
} catch (_: Exception) { emptyList() }

private fun saveList(prefs: android.content.SharedPreferences, key: String, list: List<String>) {
    prefs.edit().putString(key, JSONArray(list).toString()).apply()
}
