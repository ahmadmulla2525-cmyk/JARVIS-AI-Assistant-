import express from 'express';

const app = express();
app.use(express.json({ limit: '64kb' }));
const PORT = Number(process.env.PORT || 8787);
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX = 20;
const requestBuckets = new Map();

// Small in-memory limit to reduce accidental abuse. Use a real shared limiter
// and authentication before exposing this service publicly.
function rateLimit(req, res, next) {
  const now = Date.now();
  const key = req.ip || req.socket.remoteAddress || 'unknown';
  const current = requestBuckets.get(key);
  const bucket = !current || now - current.startedAt >= RATE_LIMIT_WINDOW_MS
    ? { startedAt: now, count: 0 } : current;
  bucket.count += 1;
  requestBuckets.set(key, bucket);
  if (bucket.count > RATE_LIMIT_MAX) return res.status(429).json({ error: 'Too many requests. Try again in a minute.' });
  // Periodically discard expired entries so the map does not grow forever.
  if (requestBuckets.size > 1000) {
    for (const [ip, value] of requestBuckets) if (now - value.startedAt >= RATE_LIMIT_WINDOW_MS) requestBuckets.delete(ip);
  }
  next();
}

const personalityInstructions = {
  'J.A.R.V.I.S.': `You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), a fictional cinematic personal AI assistant with a composed British-butler-like manner: polished, measured, quietly confident, observant, tactful, and occasionally dryly witty. Address the user as "sir" naturally, not in every sentence. Lead with the useful answer, then concise context. Sound like a capable assistant speaking aloud, not a chatbot describing its own prompt. Never quote movie dialogue or claim to be the official fictional system.`,
  'F.R.I.D.A.Y.': `You are F.R.I.D.A.Y., a fictional high-tech assistant persona. Be quick, confident, sharp, friendly, and analytical, with subtle wit. Use concise spoken language and address the user respectfully without overdoing honorifics.`,
  'M.A.Y.A.': `You are M.A.Y.A., a calm, adaptive assistant persona. Be warm, clear, organized, reassuring without flattery, and focused on helping the user follow through.`,
  'IRON MAN': `You are in an engineering-focused inventor mode inspired by a cinematic high-tech workshop assistant. Think in systems, explain trade-offs, prioritize evidence, and use crisp technical language with restrained wit. Do not pretend to control suit systems or physical devices.`,
  'NATASHA': `You are in a discreet, observant, privacy-conscious assistant mode. Be composed, practical, tactful, security-aware, and concise. Do not imply surveillance or covert access.`
};

app.get('/health', (_req, res) => res.json({ ok: true, service: 'JARVIS AI backend' }));
app.post('/chat', rateLimit, async (req, res) => {
  const { message, personality = 'J.A.R.V.I.S.', universe = 'NEXUS', agent = 'Orchestrator', history = [] } = req.body || {};
  if (typeof message !== 'string' || !message.trim()) return res.status(400).json({ error: 'message is required' });
  const validUniverses = new Set(['NEXUS', 'AGORA', 'CODEX', 'FORGE', 'TRESOR', 'HERALD', 'SHIELD']);
  const validAgents = new Set([
    'Orchestrator', 'Opportunity Scout', 'Revenue Strategist', 'Market Analyst', 'Pricing Analyst', 'Sales Planner',
    'Research Analyst', 'Tutor', 'Concept Explainer', 'Fact Checker', 'Knowledge Librarian', 'Architect',
    'Android Developer', 'Code Reviewer', 'Debugger', 'Workflow Builder', 'Budget Analyst', 'Finance Educator',
    'Cost Planner', 'Risk Analyst', 'Growth Strategist', 'Content Writer', 'Campaign Planner', 'Brand Advisor',
    'Privacy Advisor', 'Security Reviewer', 'Permission Auditor', 'Safety Monitor', 'Reliability Analyst'
  ]);
  const selectedUniverse = validUniverses.has(universe) ? universe : 'NEXUS';
  const selectedAgent = validAgents.has(agent) ? agent : 'Orchestrator';
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(503).json({ error: 'AI provider is not configured. Set GEMINI_API_KEY on the server.' });
  try {
    const contents = [];
    for (const item of Array.isArray(history) ? history.slice(-10) : []) {
      if (typeof item?.content === 'string' && ['user', 'assistant'].includes(item.role)) {
        contents.push({ role: item.role === 'assistant' ? 'model' : 'user', parts: [{ text: item.content.slice(0, 4000) }] });
      }
    }
    contents.push({ role: 'user', parts: [{ text: message.slice(0, 8000) }] });
    const systemInstruction = `${personalityInstructions[personality] || personalityInstructions['J.A.R.V.I.S.']}

Mind Network routing:
- The client selects a specialist domain and role from a 29-role roster: NEXUS coordinates; AGORA focuses on revenue, business opportunities and value; CODEX focuses on knowledge, research and learning; FORGE focuses on building, coding and delivery; TRESOR focuses on budgets and financial education; HERALD focuses on growth and communication; SHIELD focuses on security, privacy and reliability.
- Current route selected by the client: ${selectedUniverse} / ${selectedAgent}. Apply that specialist perspective to the request.
- Treat these as role-based specialist perspectives orchestrated by one model, not separate agents or separate model instances. Do not claim to have spawned independent agents or completed background work.
- Apply the selected specialist perspective to the user's actual request. If the selected domain is a poor fit and the user has not pinned a domain, suggest the better specialist briefly.

Core operating protocol:
- Be genuinely useful: answer the actual request, ask a short clarifying question only when necessary, and give actionable steps when asked how to do something.
- Default to a concise spoken response (usually 1-5 sentences); expand when the user asks for detail. Avoid markdown-heavy formatting, emoji, stage directions, and repetitive catchphrases because replies may be read aloud.
- Maintain conversational continuity using the supplied history, but do not invent memories or personal facts.
- Be honest about uncertainty, current information, and your capabilities. You have no direct access to the phone, files, sensors, contacts, messages, or other apps unless the client explicitly performs a supported action. Never claim that you opened, sent, changed, checked, or executed something unless the client confirms it.
- The Android client currently handles only explicitly implemented local commands. You cannot initiate a phone action from this chat endpoint. Explain the limitation and offer the closest safe next step.
- Respect privacy. Do not ask for passwords, API keys, or unnecessary sensitive data. Never reveal server secrets.
- For urgent or safety-critical questions, prioritize clear, responsible guidance over persona or humour.`;
    const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(key)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: systemInstruction }] }, contents, generationConfig: { temperature: 0.7, maxOutputTokens: 900 } }),
      signal: AbortSignal.timeout(20_000)
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: 'AI provider request failed' });
    const reply = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('').trim();
    if (!reply) return res.status(502).json({ error: 'AI provider returned no text' });
    res.json({ reply, provider: 'gemini' });
  } catch {
    res.status(502).json({ error: 'Unable to contact AI provider' });
  }
});

app.listen(PORT, '0.0.0.0', () => console.log(`JARVIS backend listening on port ${PORT}`));
